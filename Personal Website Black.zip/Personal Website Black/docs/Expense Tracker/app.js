document.getElementById('expenseForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var date = document.getElementById('date').value;
    var category = document.getElementById('category').value;
    var amount = document.getElementById('amount').value;
    var editIndex = document.getElementById('editIndex').value;
  
    if (editIndex === '') {
      var expenses = JSON.parse(localStorage.getItem('expenses')) || [];
      expenses.push({date: date, category: category, amount: amount});
      localStorage.setItem('expenses', JSON.stringify(expenses));
    } else {
      var expenses = JSON.parse(localStorage.getItem('expenses')) || [];
      expenses[editIndex] = {date: date, category: category, amount: amount};
      localStorage.setItem('expenses', JSON.stringify(expenses));
      document.getElementById('editIndex').value = '';
    }
  
    document.getElementById('date').value = '';
    document.getElementById('category').value = '';
    document.getElementById('amount').value = '';
  
    showExpenses();
  });
  
  function showExpenses() {
    var expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    var tableBody = document.getElementById('expenseTable');
    tableBody.innerHTML = '';
  
    for (var i = 0; i < expenses.length; i++) {
      var expense = expenses[i];
      var row = `<tr>
                   <td>${expense.date}</td>
                   <td>${expense.category}</td>
                   <td>${expense.amount}</td>
                   <td>
                     <button type="button" class="btn btn-sm btn-primary" onclick="editForm(${i}, '${expense.date}', '${expense.category}', '${expense.amount}')">Edit</button>
                     <button type="button" class="btn btn-sm btn-danger" onclick="deleteExpense(${i})">Delete</button>
                   </td>
                 </tr>`;
      tableBody.insertAdjacentHTML('beforeend', row);
    }
  }
  
  function editForm(index, date, category, amount) {
    document.getElementById('date').value = date;
    document.getElementById('category').value = category;
    document.getElementById('amount').value = amount;
    document.getElementById('editIndex').value = index;
    document.getElementById('addButton').innerHTML = 'Update Expense';
  }
  
  function deleteExpense(index) {
    var expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    expenses.splice(index, 1);
    localStorage.setItem('expenses', JSON.stringify(expenses));
    showExpenses();
  }
  
  showExpenses();